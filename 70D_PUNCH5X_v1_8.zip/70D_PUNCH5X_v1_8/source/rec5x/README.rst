Raw video REC5X (MLV Lite + 1x/5x switch)
=========================================

mlv_lite (magiclantern_simplified @ 1a0600a) with one addition for the 70D:
"1x/5x while recording". With PUNCH5X, the magnify key switches Canon
between 1x and its real 5x during a clip; the clip goes on, the output size
stays the same and is taken from the centre of each frame. A few frames are
left out at each switch. Everything else is stock mlv_lite.

Load either REC5X or mlv_lite, not both.

:Authors: g3gg0, a1ex, dmilligan; zoom switch: Claude (Anthropic) for Petar Stipanovic
:License: GPL
:Summary: mlv_lite + keep recording through 1x/5x switches (70D)
