/* punch5x.c - Canon EOS 70D (1.1.2): 5x punch-in while recording (v1.8)
 *
 * The magnify key switches LiveView between Canon's 1x and Canon's real 5x (also while a RAW
 * recorder runs, which normally blocks that key), and Canon's 5x is made to run at the movie
 * frame rate instead of its own 29.97 fps. Everything else - raw window, rows, columns (the
 * AF box), exposure, AF - is Canon's own, so the screen is Canon's normal 5x screen.
 *
 * The RAW frame size changes with the zoom (1x: 1984 x 1250, 3x3 binned; 5x: 3616 x 1346, 1:1).
 * A stock recorder ends the clip at that point; REC5X (mlv_lite + "1x/5x while recording")
 * keeps going and takes the same output size from the centre of each frame.
 *
 * Frame rate in 5x (from CROP60 "24p crop (5x)", proven on the camera, V25/V26 probes):
 *   ENGIO  Timer B  C0F06014 / C0F06024: Canon 0x633 (+-3) -> Timer B for the movie fps
 *          VD late  C0F07064:            Canon 0x5F6 (+-8) -> + the same difference
 *   ADTG   dst 2 0x8173 / 0x8179 (PowerSave OFF, Gray coded): Canon 1540 (+-4) -> + difference
 *          dst 4 0x8179 (sensor frame length, Gray coded):    Canon 1588 (+-4) -> + difference
 *   Only Canon's own 5x values are touched (1x and 10x values never match); Canon writes
 *   Timer B every frame, so switching the module off gives Canon's timing back at once,
 *   the ADTG values with the next zoom change (done for you when not recording).
 *   Timer B = round(32 MHz / (Timer A + 1) / fps) - 1, Timer A in 5x = 0x29F:
 *   23.976 -> 0x7C1, 25 -> 0x770 (Canon 5x: 0x633 = 29.99 fps).
 *
 * Key order: ML calls module key handlers in alphabetical order; "punch5x" comes before
 * "rec5x" (and after "mlv_lite" - don't load the stock mlv_lite with it).
 *
 * Packets are copied, never edited in place. Canon's vsnprintf: only %d %x %s.
 *
 * v1.1: "Punch-in frame": in 1x, a faint dotted rectangle where the 5x punch-in will record.
 *   Size = REC5X's output size (rec5x_get_res, weak: menu fallback if REC5X isn't loaded),
 *   1:1 sensor pixels. Position = Canon's 5x window for the current AF box: start column
 *   floor((box_x - 1736) / 120) * 120, start row floor((box_y - 659) / 120) * 120 (CMOS[7] and
 *   CMOS[11] are set in 120-pixel steps; a centred box gives columns from 960 and rows from
 *   1080, as logged), clamped to the sensor; the recording is centred in the 3472 x 1318
 *   picture of that window. Sensor -> screen through ML's "os" (the 3:2 image on the LCD).
 *
 * v1.2: field v1.1: the recording was ~1000 columns left of (and a bit above) what the 5x screen
 *   showed. Canon only moves its 5x readout window when the AF box would leave it (CROP60 run D2
 *   sweep): a centred box keeps columns 0-3472, so the screen (the box, column 2736) is far right
 *   in the window and REC5X's window-centred crop sat at column 1736. Now:
 *   - a read-only CMOS hook notes Canon's real 5x window (CMOS[7] start column, CMOS[11] rows);
 *     punch5x_get_window() gives it to REC5X, which centres the crop on the AF box inside it
 *     (clamped at the window's edges) and follows the box if it moves during a clip;
 *   - the frame in 1x is centred on the AF box, clamped to the window Canon will choose:
 *     columns from 0 unless the box (1/5 of the width) would stick out on the right, then the
 *     smallest 120-step start that holds it; rows centred on the box - 87, in 120 steps.
 *
 * v1.3: field v1.2 (1832x1030, box centred, window seen: columns 0.., rows 1080..): the
 *   recording sat 180 columns left of the 5x screen - a crop centred on the box would need
 *   columns up to 3652, Canon's window ends at 3472. "Align AF box": just before punching in,
 *   the AF box is moved (ML's move_lv_afframe, in 1x) to the middle of the area that will
 *   really be recorded (the dotted frame), so box = 5x screen = recording; it goes back when
 *   you punch out. The frame does not move: it already showed the recorded area.
 *
 * v1.4: with REC5X v1.4 (16 columns kept clear at the right of Canon's 5x frame - its 8 non-picture
 *   columns made the lossless encoder fail, field v1.3 "Compression error -3"): the frame and the
 *   AF-box alignment use the same 3456-column limit.
 *
 * v1.5: field v1.4 log: "align: AF box 2736,1824 -> 2540,1640 (wanted 2540,1824)", and moving
 *   back by +184 rows did nothing - the 70D takes 184 rows off every vertical position ML sends
 *   (ML only compensates an X quirk); the box crept up at each punch-in and the recording with
 *   it. The box is now placed in a loop: move, read where it landed, learn the offset
 *   (kept for the session), correct (max 3 tries); the way back goes to the exact old spot.
 *
 * v1.6: field v1.5: the loop reached the target but needed 2-3 moves; the camera snaps the box to
 *   184-row positions (sometimes one step low: asked 1824 -> 1640, asked 2008 -> 1824 or 2008),
 *   so a fixed learned offset over- or undershoots. Now: aim half a step (92 rows) high, which
 *   lands on the wanted position with either rounding; at most one correction. And the box is
 *   only moved when LiveView is idle right now (no waiting): at 61.4 s it wasn't (the recorder
 *   was already stopping) and v1.5 spent 2 s retrying before the zoom.
 *
 * v1.8: no log file (PUNCH5X_LOG=0; build with -DPUNCH5X_LOG=1 for ML/PUNCH5X.LOG).
 * v1.7: field v1.6 (chart test): recording = Canon's 5x view, but both ~1 chart column left of
 *   the centre: with Canon's own readout (columns 0-3472 for a centred box) an 1832-wide recording
 *   centred on the middle needs columns up to 3652 - the v1.3 alignment only made screen and
 *   recording agree on a point 196 columns left. And the half-step rule of v1.6 missed (moves to
 *   the right land exactly, others 184 rows low): back to the v1.5 measure-and-correct loop
 *   (3 tries), still never waiting for a busy LiveView.
 *   "Centre 5x readout" (new, default on): at punch-in Canon's 5x readout start (CMOS[7],
 *   120-column steps) is set so the readout is centred on the AF box (where you aimed, V), and
 *   the box is moved left by the same amount S. Canon places its 5x screen from the box inside
 *   the window it believes it has (start 0), so the picture on the screen comes from sensor
 *   column S + (V - S) = V again; REC5X centres on that screen position using Canon's own window
 *   numbers (punch5x_get_window keeps returning Canon's value), which shift by the same S -
 *   so the recording is centred on V with no clamp. Undone at punch-out (readout back to
 *   Canon's own on the next 5x, box back to V).
 */
#include <dryos.h>
#include <module.h>
#include <config.h>
#include <menu.h>
#include <property.h>
#include <propvalues.h>
#include <patch.h>
#include <bmp.h>
#include <lvinfo.h>
#include <fps.h>
#include <shoot.h>
#include <zebra.h>
void move_lv_afframe(int dx, int dy);

/* REC5X's output size (if REC5X isn't loaded this calls ret_0 = "unknown") */
extern WEAK_FUNC(ret_0) int rec5x_get_res(int *w, int *h);

/* ---- 70D 1.1.2 ---------------------------------------------------------- */
#define CMOS_WRITE_70D          0x00026B54
#define MEM_CMOS_WRITE_70D      0xE92D41F0
#define ADTG_WRITE_70D          0x0002684C
#define MEM_ADTG_WRITE_70D      0xE92D47F0
#define ENGIO_WRITE_70D         0xFF2BC6C4
#define MEM_ENGIO_WRITE_70D     0xE51FC15C

#define REG_TIMER_B             0xC0F06014
#define REG_TIMER_B2            0xC0F06024
#define REG_VD_LATE             0xC0F07064
#define REG_RAW_TL              0xC0F06800
#define REG_RAW_BR              0xC0F06804

#define C5X_TA                  0x29F
#define C5X_TB                  0x633
#define C5X_VD_LATE             0x5F6
#define C5X_PS_OFF              1540
#define C5X_VD_LEN              1588
#define TG_FREQ                 32000000u

/* ---- state ------------------------------------------------------------- */
static CONFIG_INT("punch5x.enabled", p5_enabled, 1);
static CONFIG_INT("punch5x.fps", p5_fps_mode, 0);      /* 0 = movie fps in 5x, 1 = Canon's 30 fps */
static CONFIG_INT("punch5x.frame", p5_frame, 1);       /* punch-in frame: 0 off, 1 faint, 2 bright */
static CONFIG_INT("punch5x.frame_h", p5_frame_h, 1);
static CONFIG_INT("punch5x.align", p5_align, 1);      /* move the AF box onto the recorded area at punch-in */
static CONFIG_INT("punch5x.centre", p5_centre, 1);    /* v1.7: centre Canon's 5x readout on the aim point */   /* without REC5X: 0 = 1832x766, 1 = 1832x1030, 2 = 1832x1222 */

static volatile int hooks_installed = 0;
static volatile int timing_on = 0;          /* hooks change Canon's 5x timing */
static volatile int delta = 0;              /* our Timer B - Canon's 5x Timer B */
static int tb_ours = 0;                     /* Timer B for the movie fps */
static int armed_fps = 0;
static volatile int key_req = 0;            /* magnify pressed */
static volatile int quit = 0;
static volatile int rezoom_pending = 0;     /* Canon's own 5x timing back after the next zoom */
static volatile uint32_t subs_engio = 0, subs_adtg = 0;
static char status[96] = "starting";

/* ---- log: ML/PUNCH5X.LOG (this session), .OLD (previous) ---------------- */
/* v1.8: no log file unless built with -DPUNCH5X_LOG=1 (the lines still go to a RAM ring) */
#ifndef PUNCH5X_LOG
#define PUNCH5X_LOG 0
#endif
#define LOG_LINES 40
static char log_ring[LOG_LINES][96];
static int log_head = 0, log_count = 0;
static uint32_t log_t0 = 0;
static volatile int log_dirty = 0;
static void log_line(const char *fmt, ...)
{
    char *l = log_ring[log_head];
    uint32_t ms = get_ms_clock() - log_t0;
    int n = snprintf(l, 24, "%d.%d ", ms / 1000, (ms / 100) % 10);
    if (n < 0 || n > 23) n = 0;
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(l + n, sizeof(log_ring[0]) - n - 1, fmt, ap);
    va_end(ap);
    log_head = (log_head + 1) % LOG_LINES;
    if (log_count < LOG_LINES) log_count++;
    log_dirty = 1;
}
static void log_flush(void)
{
    if (!PUNCH5X_LOG) { log_dirty = 0; return; }
    if (!log_dirty) return;
    log_dirty = 0;
    FILE *f = FIO_CreateFile("ML/PUNCH5X.LOG");
    if (!f) return;
    static char buf[LOG_LINES * 97];
    int len = 0;
    for (int i = 0; i < log_count; i++)
    {
        const char *l = log_ring[(log_head - log_count + i + LOG_LINES) % LOG_LINES];
        int n = 0;
        while (n < 95 && l[n]) n++;
        memcpy(buf + len, l, n); len += n;
        buf[len++] = '\n';
    }
    FIO_WriteFile(f, buf, len);
    FIO_CloseFile(f);
}
static void set_status(const char *fmt, ...)
{
    char s[96];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s, sizeof(s) - 1, fmt, ap);
    va_end(ap);
    if (strcmp(s, status) == 0) return;
    strcpy(status, s);
    log_line("%s", status);
}

/* ---- helpers ------------------------------------------------------------ */
static inline uint32_t gray_enc(uint32_t x) { return x ^ (x >> 1); }
static inline uint32_t gray_dec(uint32_t g) { uint32_t x = 0; while (g) { x ^= g; g >>= 1; } return x; }
static inline int near_i(int a, int b, int tol) { int d = a - b; return d >= -tol && d <= tol; }

static int timer_b_for(int fps_x1000, uint32_t timer_a)
{
    uint32_t ta = (timer_a & 0xFFFF) + 1;
    if (ta < 100 || fps_x1000 < 1000) return 0;
    uint32_t q = TG_FREQ / ta, rem = TG_FREQ - q * ta;
    uint32_t f = q * 1000 + rem * 1000 / ta;
    uint32_t lines = (f + (uint32_t) fps_x1000 / 2) / (uint32_t) fps_x1000;
    return (int) lines - 1;
}

static int movie_1080(void)
{
    return lv && is_movie_mode() && video_mode_resolution == 0 && !video_mode_crop;
}

/* the Canon movie settings the timing belongs to - not LiveView itself: LiveView pauses (the
 * recorder writing out its buffer, Canon menu, playback) must not switch the timing off and on
 * again (v1.0 field log: a needless 1x -> 5x hop after each stop in 5x) */
static int movie_1080_setting(void)
{
    return is_movie_mode() && video_mode_resolution == 0 && !video_mode_crop;
}

static int movie_fps_x1000(void)
{
    return video_mode_fps == 25 ? 25000 : video_mode_fps == 24 ? 23976 : 0;   /* 30p: Canon's 5x already matches */
}

/* raw size from Canon's registers (as ML computes it on the 70D) */
static void raw_size(int *w, int *h)
{
    uint32_t tl = shamem_read(REG_RAW_TL), br = shamem_read(REG_RAW_BR);
    *w = ((int)(br & 0xFFFF) - (int)(tl & 0xFFFF)) * 8;
    *h = (int)(br >> 16) - (int)(tl >> 16) - 1;
}

/* ---- hooks ---------------------------------------------------------------- */
static uint32_t engio_copy[4][2 * 1024 + 2];
static uint32_t adtg_copy[4][512];
static volatile uint32_t engio_slot = 0, adtg_slot = 0;

static int engio_new(uint32_t reg, uint32_t val, uint32_t *out)
{
    if (reg == REG_TIMER_B || reg == REG_TIMER_B2)
    {
        if (!near_i((int)(val & 0xFFFF), C5X_TB, 3)) return 0;
        *out = (val & 0xFFFF0000u) | (((val & 0xFFFF) + (uint32_t) delta) & 0xFFFF);
        return 1;
    }
    if (reg == REG_VD_LATE)
    {
        if (!near_i((int) val, C5X_VD_LATE, 8)) return 0;
        *out = (uint32_t)((int) val + delta);
        return 1;
    }
    return 0;
}

static void engio_hook(uint32_t *regs, uint32_t *stack, uint32_t pc)
{
    if (!timing_on || !delta) return;
    uint32_t *src = (uint32_t *) regs[0];
    if (!src) return;
    uint32_t n = 0, nv;
    int need = 0;
    while (n < 1023 && src[2*n] != 0xFFFFFFFF)
    {
        if (engio_new(src[2*n], src[2*n + 1], &nv)) need = 1;
        n++;
    }
    if (n >= 1023 || !need) return;
    uint32_t slot = (engio_slot + 1) & 3;
    engio_slot = slot;
    uint32_t *dst = engio_copy[slot];
    for (uint32_t i = 0; i < n; i++)
    {
        uint32_t reg = src[2*i], val = src[2*i + 1];
        if (engio_new(reg, val, &nv)) val = nv;
        dst[2*i] = reg;
        dst[2*i + 1] = val;
    }
    dst[2*n] = 0xFFFFFFFF;
    dst[2*n + 1] = 0;
    regs[0] = (uint32_t) dst;
    subs_engio++;
}

static int adtg_new(int dst, uint32_t reg, uint32_t val, uint32_t *out)
{
    int match;
    if (dst == 2 && (reg == 0x8173 || reg == 0x8179)) match = C5X_PS_OFF;
    else if (dst == 4 && reg == 0x8179) match = C5X_VD_LEN;
    else return 0;
    int x = (int) gray_dec(val & 0xFFFF);
    if (!near_i(x, match, 4)) return 0;
    x += delta;
    if (x <= 0 || x > 0xFFFF) return 0;
    *out = gray_enc((uint32_t) x) & 0xFFFF;
    return *out != (val & 0xFFFF);
}

static void adtg_hook(uint32_t *regs, uint32_t *stack, uint32_t pc)
{
    if (!timing_on || !delta) return;
    int dst = regs[0] & 0xF;
    uint32_t *src = (uint32_t *) regs[1];
    if (!src) return;
    int n = 0, need = 0;
    uint32_t nv;
    while (n < 511 && src[n] != 0xFFFFFFFF)
    {
        if (adtg_new(dst, src[n] >> 16, src[n] & 0xFFFF, &nv)) need = 1;
        n++;
    }
    if (n >= 511 || !need) return;
    uint32_t slot = (adtg_slot + 1) & 3;
    adtg_slot = slot;
    uint32_t *out = adtg_copy[slot];
    for (int i = 0; i < n; i++)
    {
        uint32_t w = src[i];
        if (adtg_new(dst, w >> 16, w & 0xFFFF, &nv)) w = (w & 0xFFFF0000u) | nv;
        out[i] = w;
    }
    out[n] = 0xFFFFFFFF;
    regs[1] = (uint32_t) out;
    subs_adtg++;
}

/* read-only: Canon's own 5x window (CMOS[7] = 0xC00 | start/120 << 4 with 1:1 columns,
 * CMOS[11] = last/120 << 5 | first/120) */
static volatile int cmos_hooked = 0;
static volatile int win_c7 = -1, win_c11 = -1;
static volatile int ov_start = -1;          /* v1.7: our 5x readout start (sensor columns, 120 steps), -1 = Canon's */
static volatile uint32_t ov_subs = 0;
static uint16_t cmos_copy[4][72];
static volatile uint32_t cmos_slot = 0;
static void cmos_hook(uint32_t *regs, uint32_t *stack, uint32_t pc)
{
    uint16_t *src = (uint16_t *) regs[0];
    if (!src) return;
    int c7 = -1, c11 = -1, n = 0;
    for (; n < 64 && src[n] != 0xFFFF; n++)
    {
        int r = src[n] >> 12;
        if (r == 7) c7 = src[n] & 0xFFF;
        else if (r == 11) c11 = src[n] & 0xFFF;
    }
    if (n >= 64) return;
    if (c7 >= 0 && !(c7 & 0x008) && (c7 & 0xF00) == 0xC00)    /* 1:1 columns = 5x / 10x */
    {
        win_c7 = c7;                        /* Canon's own value (REC5X positions from it) */
        if (c11 >= 0) win_c11 = c11;
        int s = ov_start;
        if (s >= 0 && lv_dispsize != 10)
        {
            uint16_t want = (uint16_t)(0xC00 | (((s / 120) & 0x1F) << 4) | (c7 & 0x00F));
            if (want != c7)
            {
                uint32_t slot = (cmos_slot + 1) & 3;
                cmos_slot = slot;
                uint16_t *dst = cmos_copy[slot];
                for (int i = 0; i < n; i++)
                    dst[i] = ((src[i] >> 12) == 7) ? (uint16_t)((7 << 12) | want) : src[i];
                dst[n] = 0xFFFF;
                regs[0] = (uint32_t) dst;
                ov_subs++;
            }
        }
    }
}

/* for REC5X: Canon's 5x window now (sensor start column, first row); 0 = unknown */
int punch5x_get_window(int *col0, int *row0)
{
    if (!cmos_hooked || win_c7 < 0 || win_c11 < 0 || lv_dispsize != 5) return 0;
    *col0 = ((win_c7 >> 4) & 0x1F) * 120;
    *row0 = (win_c11 & 0x1F) * 120;
    return 1;
}

static int install_cmos(void)
{
    if (cmos_hooked) return 1;
    if (patch_hook_function(CMOS_WRITE_70D, MEM_CMOS_WRITE_70D, cmos_hook, "PUNCH5X CMOS")) return 0;
    cmos_hooked = 1;
    return 1;
}

static int install_hooks(void)
{
    if (hooks_installed) return 1;
    if (patch_hook_function(ADTG_WRITE_70D, MEM_ADTG_WRITE_70D, adtg_hook, "PUNCH5X ADTG")) return 0;
    if (patch_hook_function(ENGIO_WRITE_70D, MEM_ENGIO_WRITE_70D, engio_hook, "PUNCH5X ENGIO"))
    {
        unpatch_memory(ADTG_WRITE_70D);
        return 0;
    }
    hooks_installed = 1;
    return 1;
}

static void remove_hooks(void)
{
    timing_on = 0;
    if (cmos_hooked) { unpatch_memory(CMOS_WRITE_70D); cmos_hooked = 0; }
    if (!hooks_installed) return;
    unpatch_memory(ENGIO_WRITE_70D);
    unpatch_memory(ADTG_WRITE_70D);
    hooks_installed = 0;
}

/* ---- frame timing watch (vsync) -------------------------------------------- */
static volatile uint32_t vs_prev = 0, vs_count = 0, vs_slow = 0, vs_slow_max = 0;
static volatile uint32_t frame_us = 41708;
static unsigned int vsync_cbr(unsigned int ctx)
{
    uint32_t t = GET_DIGIC_TIMER();
    uint32_t dt = (t - vs_prev) & (DIGIC_TIMER_MAX - 1);
    vs_prev = t;
    vs_count++;
    /* sustained frames 1.5-3x too long at our timing = a real timing problem (a single long gap
     * is Canon pausing LiveView: zoom, AF, box moves) */
    if (timing_on && delta && lv_dispsize == 5 && dt > frame_us + frame_us / 2 && dt < 3 * frame_us)
    {
        vs_slow++;
        if (vs_slow > vs_slow_max) vs_slow_max = vs_slow;
    }
    else vs_slow = 0;
    return 0;
}

/* ---- keys ------------------------------------------------------------------ */
static unsigned int punch_keypress(unsigned int key)
{
    if (key != MODULE_KEY_PRESS_ZOOMIN) return 1;
    if (!p5_enabled || !movie_1080() || gui_menu_shown()) return 1;
    if (lv_dispsize != 1 && lv_dispsize != 5 && lv_dispsize != 10) return 1;
    key_req = 1;
    return 0;
}

/* ---- punch-in frame (1x) --------------------------------------------------------- */
#define C5X_PIC_W   3472                    /* Canon's 5x picture (raw 3616 x 1346 minus margins) */
#define C5X_PIC_H   1318
#define C5X_REC_W   3456                    /* what REC5X may record from: 16 columns kept clear on the right
                                               (Canon's 5x has 8 non-picture columns there) */
static int fr_drawn = 0, fr_x = 0, fr_y = 0, fr_w = 0, fr_h = 0, fr_color = 0;
static int fr_res_w = 0, fr_res_h = 0, fr_from_rec = 0;
static int fr_start = 0;                    /* readout start of the last plan (sensor columns) */

static int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }

/* dotted outline; erase = put back transparency only where our dots still are */
static void fr_outline(int x, int y, int w, int h, int color, int erase)
{
    for (int i = 0; i <= w; i += 3)
        for (int k = 0; k < 2; k++)
        {
            int px = x + i, py = k ? y + h : y;
            if (erase) { if (bmp_getpixel(px, py) == color) bmp_putpixel(px, py, COLOR_EMPTY); }
            else bmp_putpixel(px, py, color);
        }
    for (int j = 3; j < h; j += 3)
        for (int k = 0; k < 2; k++)
        {
            int px = k ? x + w : x, py = y + j;
            if (erase) { if (bmp_getpixel(px, py) == color) bmp_putpixel(px, py, COLOR_EMPTY); }
            else bmp_putpixel(px, py, color);
        }
}

static void fr_erase(void)
{
    if (!fr_drawn) return;
    fr_outline(fr_x, fr_y, fr_w, fr_h, fr_color, 1);
    fr_drawn = 0;
}

/* where the 5x punch-in will record, in sensor pixels (top-left, size) and the AF box now */
static int fr_sensor(int *sxo, int *syo, int *rwo, int *rho, int *bxo, int *byo, int *Wo, int *Ho)
{
    int W = 0, H = 0, bx = 0, by = 0;
    get_afframe_sensor_res(&W, &H);
    if (W < C5X_PIC_W || H < C5X_PIC_H) return 0;
    get_afframe_pos(W, H, &bx, &by);
    int rw = 0, rh = 0;
    fr_from_rec = rec5x_get_res(&rw, &rh) ? 1 : 0;
    if (!fr_from_rec || rw <= 0 || rh <= 0)
    {
        static const int hs[3] = { 766, 1030, 1222 };
        rw = 1832; rh = hs[clampi(p5_frame_h, 0, 2)];
    }
    fr_res_w = rw; fr_res_h = rh;
    /* the window Canon will choose (CROP60 run D2): columns from 0 unless the box (1/5 of the
     * width) would stick out on the right; rows centred on the box - 87, both in 120 steps */
    int bw = W / 5;
    int c0 = 0;
    if (bx + bw / 2 > C5X_PIC_W) c0 = ((bx + bw / 2 - C5X_PIC_W + 119) / 120) * 120;
    c0 = clampi(c0, 0, ((W - C5X_PIC_W) / 120) * 120);
    int r0 = clampi(((by - 87 - C5X_PIC_H / 2 + 60) / 120) * 120, 0, ((H - C5X_PIC_H) / 120) * 120);
    /* v1.7 centred readout: our own start, centred on the aim point (the box) */
    if (p5_centre && cmos_hooked)
        c0 = clampi(((bx - C5X_REC_W / 2 + 60) / 120) * 120, 0, ((W - C5X_PIC_W) / 120) * 120);
    /* REC5X centres the recording on the aim point, inside that window */
    int sx = clampi(bx - rw / 2, c0, c0 + C5X_REC_W - rw);
    int sy = clampi(by - rh / 2, r0, r0 + C5X_PIC_H - rh);
    *sxo = sx; *syo = sy; *rwo = rw; *rho = rh; *bxo = bx; *byo = by; *Wo = W; *Ho = H;
    fr_start = c0;
    return 1;
}

/* the same, in BMP (screen) coordinates; 0 if unknown */
static int fr_rect(int *x, int *y, int *w, int *h)
{
    int sx, sy, rw, rh, bx, by, W, H;
    if (os.x_ex <= 0 || os.y_ex <= 0 || !fr_sensor(&sx, &sy, &rw, &rh, &bx, &by, &W, &H)) return 0;
    /* sensor -> screen (os = the 3:2 image on the LCD, as ML draws the AF box) */
    *x = os.x0 + sx * os.x_ex / W;
    *y = os.y0 + sy * os.y_ex / H;
    *w = rw * os.x_ex / W;
    *h = rh * os.y_ex / H;
    return *w > 4 && *h > 4;
}

/* worker, every 50 ms: keep the frame drawn in 1x (Canon and ML overlays may paint over it) */
static void fr_service(void)
{
    static uint32_t t_last = 0;
    int show = p5_enabled && p5_frame && movie_1080() && lv_dispsize == 1 && !gui_menu_shown()
               && liveview_display_idle();
    if (!show) { if (lv_dispsize != 1 || !p5_frame || !p5_enabled) fr_erase(); return; }
    if (get_ms_clock() - t_last < 200) return;
    t_last = get_ms_clock();
    int x, y, w, h;
    if (!fr_rect(&x, &y, &w, &h)) { fr_erase(); return; }
    int color = p5_frame == 2 ? COLOR_WHITE : COLOR_GRAY(70);
    if (fr_drawn && (x != fr_x || y != fr_y || w != fr_w || h != fr_h || color != fr_color)) fr_erase();
    fr_outline(x, y, w, h, color, 0);
    fr_x = x; fr_y = y; fr_w = w; fr_h = h; fr_color = color;
    fr_drawn = 1;
}

/* ---- align the AF box with the recorded area (v1.3, closed loop v1.5) ------------- */
static int al_on = 0, al_home_x = 0, al_home_y = 0;   /* where the box was before we moved it */

static void box_now(int *x, int *y)
{
    int W = 0, H = 0;
    get_afframe_sensor_res(&W, &H);
    *x = *y = -1;
    if (W > 0 && H > 0) get_afframe_pos(W, H, x, y);
}

/* move the box to (tx, ty) in sensor pixels: request, see where it landed, correct (the camera
 * lands some moves 184 rows off - v1.5/v1.6 logs), learn the offset for the session; at most 3
 * moves, 300 ms each; never waits for LiveView: if it isn't idle right now, nothing is moved */
static int off_x = 0, off_y = 0;
static int box_move_to(int tx, int ty)
{
    int cx, cy;
    box_now(&cx, &cy);
    if (cx < 0) return 0;
    for (int k = 0; k < 3; k++)
    {
        int ex = tx - cx, ey = ty - cy;
        if (ABS(ex) < 16 && ABS(ey) < 16) return 1;
        if (!liveview_display_idle()) { log_line("  box not moved: LiveView busy"); return 0; }
        int dx = ex + off_x, dy = ey + off_y;
        move_lv_afframe(dx, dy);
        uint32_t t = get_ms_clock();
        int nx = cx, ny = cy;
        while ((int)(get_ms_clock() - t) < 300)
        {
            msleep(20);
            box_now(&nx, &ny);
            if (nx != cx || ny != cy) break;
        }
        log_line("  box %d,%d -> %d,%d (asked %d,%d, target %d,%d)", cx, cy, nx, ny, dx, dy, tx, ty);
        if (nx == cx && ny == cy) return 0;     /* the camera didn't take it - don't insist */
        off_x = clampi(off_x + (tx - nx), -400, 400);
        off_y = clampi(off_y + (ty - ny), -400, 400);
        cx = nx; cy = ny;
    }
    return ABS(tx - cx) < 16 && ABS(ty - cy) < 16;
}

/* 1x, just before punching in: box onto the middle of what will be recorded */
static void align_before_punch(void)
{
    al_on = 0;
    if (!p5_align || lv_dispsize != 1) return;
    int sx, sy, rw, rh, bx, by, W, H;
    if (!fr_sensor(&sx, &sy, &rw, &rh, &bx, &by, &W, &H)) return;
    int tx = sx + rw / 2, ty = sy + rh / 2;
    int start = fr_start;
    if (p5_centre && cmos_hooked && start > 0)
    {
        /* centred readout: Canon's screen is placed from the box inside the window it believes
         * starts at 0, our readout starts at 'start' -> box at (aim - start) shows the aim */
        tx = tx - start;
        ov_start = start;
        log_line("centre: 5x readout from column %d, box to %d,%d (aim %d,%d)", start, tx, ty, tx + start, ty);
    }
    if (ABS(tx - bx) < 16 && ABS(ty - by) < 16) return;
    al_home_x = bx; al_home_y = by; al_on = 1;
    int ok = box_move_to(tx, ty);
    int nx, ny;
    box_now(&nx, &ny);
    log_line("align: AF box %d,%d -> %d,%d (wanted %d,%d)%s - recording %d..%d x %d..%d", bx, by, nx, ny, tx, ty, ok ? "" : " NOT REACHED", sx, sx + rw, sy, sy + rh);
}

/* 1x again: the AF box back where you had it */
static void align_after_punch(void)
{
    uint32_t t = get_ms_clock();
    while (lv_dispsize != 1 && (int)(get_ms_clock() - t) < 1500) msleep(20);
    if (lv_dispsize == 1 && ov_start >= 0) { log_line("centre: readout back to Canon's (%d CMOS[7] rewrites)", ov_subs); ov_start = -1; }
    if (!al_on) return;
    al_on = 0;
    if (lv_dispsize != 1) return;
    msleep(150);
    int ok = box_move_to(al_home_x, al_home_y);
    int nx, ny;
    box_now(&nx, &ny);
    log_line("align: AF box back to %d,%d (wanted %d,%d)%s", nx, ny, al_home_x, al_home_y, ok ? "" : " NOT REACHED");
}

/* ---- worker ------------------------------------------------------------------ */
static void zoom_to(int z)
{
    /* the property, as the key would (ML's set_lv_zoom refuses while recording) */
    prop_request_change_wait(PROP_LV_DISPSIZE, &z, 4, 1000);
}

static void rezoom_if_possible(void)
{
    if (lv_dispsize == 1) rezoom_pending = 0;   /* the next 5x entry applies the timing anyway */
    if (!rezoom_pending || RECORDING || !lv || gui_menu_shown() || lv_dispsize != 5) return;
    rezoom_pending = 0;
    log_line("5x again so Canon re-applies its own 5x timing");
    zoom_to(1); msleep(300);
    zoom_to(5);
}

static void worker(void *arg)
{
    int last_zoom = -1, last_rec = -1, slow_reported = 0, hooks_busy = 0;
    uint32_t t_flush = 0, t_hooks = 0, t_cmos = 0;
    while (!quit)
    {
        msleep(key_req ? 10 : 50);

        /* magnify: 1x <-> 5x (10x -> 1x) */
        if (key_req)
        {
            key_req = 0;
            int z = (lv_dispsize == 1) ? 5 : 1;
            log_line("magnify: %d -> %d (recording %d, Timer B %x)", lv_dispsize, z, RECORDING ? 1 : 0, shamem_read(REG_TIMER_B) & 0xFFFF);
            if (z == 5) align_before_punch();
            zoom_to(z);
            if (z == 1) align_after_punch();
        }

        /* timing for the movie fps (only 1080p 24/25, the module on, "movie fps" chosen) */
        int fps = movie_fps_x1000();
        int want = p5_enabled && p5_fps_mode == 0 && movie_1080_setting() && fps;
        if (want && (!timing_on || fps != armed_fps))
        {
            if (RECORDING && timing_on) { /* never change the frame rate while recording */ }
            else if (hooks_busy && get_ms_clock() - t_hooks < 2000) { /* try again in a moment */ }
            else if (!install_hooks())
            {
                if (!hooks_busy) log_line("ENGIO/ADTG hooks taken by another module (CROP60 mode on? crop_rec?)");
                hooks_busy = 1;
                t_hooks = get_ms_clock();
            }
            else
            {
                hooks_busy = 0;
                int tb = timer_b_for(fps, C5X_TA);
                if (tb > C5X_TB && tb < 0x3000)
                {
                    tb_ours = tb;
                    delta = tb - C5X_TB;
                    frame_us = 1000000000u / (uint32_t) fps;
                    armed_fps = fps;
                    timing_on = 1;
                    log_line("5x timing for %s fps: Timer B %x (Canon %x, +%d)", fps == 25000 ? "25" : "23.976", tb, C5X_TB, delta);
                    if (lv_dispsize == 5) rezoom_pending = 1;   /* entered before: apply on a fresh 5x */
                }
            }
        }
        else if (!want && timing_on && !RECORDING)
        {
            timing_on = 0;
            armed_fps = 0;
            log_line("5x timing off (Canon's own)");
            if (lv_dispsize == 5) rezoom_pending = 1;
        }
        rezoom_if_possible();
        if (p5_enabled && movie_1080_setting() && !cmos_hooked && get_ms_clock() - t_cmos > 2000)
        {
            t_cmos = get_ms_clock();
            if (!install_cmos()) log_line("CMOS hook taken by another module: punch-in centring uses a guess");
        }
        fr_service();

        /* status (Timer B is checked 1 s after a zoom: Canon needs a few frames) */
        int z = lv_dispsize;
        static int sz = -1;
        static uint32_t t_zoom = 0;
        if (z != sz) { sz = z; t_zoom = get_ms_clock(); }
        int settled = get_ms_clock() - t_zoom > 1000;
        if (!p5_enabled) set_status("off");
        else if (hooks_busy && want) set_status("hooks busy: set CROP60 to OFF (or unload it), no crop_rec");
        else if (!movie_1080()) set_status("waiting for movie LiveView, 1920x1080");
        else
        {
            int w, h;
            raw_size(&w, &h);
            int tb = shamem_read(REG_TIMER_B) & 0xFFFF;
            if (z == 1 && settled) set_status("ready: magnify = Canon 5x (%s), raw %dx%d", timing_on ? (armed_fps == 25000 ? "25 fps" : "23.976 fps") : "Canon fps", w, h);
            else if (z == 5)
            {
                if (timing_on && near_i(tb, tb_ours, 3)) set_status("5x at %s fps, raw %dx%d", armed_fps == 25000 ? "25" : "23.976", w, h);
                else if (timing_on && settled) set_status("5x at Canon's timing (Timer B %x) - magnify twice", tb);
                else set_status("5x at Canon's own fps, raw %dx%d", w, h);
            }
            else set_status("%dx (magnify = back to 1x)", z);
        }
        if (vs_slow >= 24 && !slow_reported)
        {
            slow_reported = 1;
            log_line("slow frames in 5x: %d in a row (frame %d us) - please send this log", vs_slow, frame_us);
            if (!RECORDING) { NotifyBox(5000, "PUNCH5X: 5x frames too slow -\nusing Canon's own 5x fps"); p5_fps_mode = 1; }
        }
        if ((z != last_zoom || (RECORDING ? 1 : 0) != last_rec) && settled)
        {
            int w, h;
            raw_size(&w, &h);
            log_line("zoom %d, recording %d, raw %dx%d, Timer B %x, subs engio %d adtg %d", z, RECORDING ? 1 : 0, w, h,
                shamem_read(REG_TIMER_B) & 0xFFFF, subs_engio, subs_adtg);
            if (z == 5)
            {
                int W = 0, H = 0, bx = 0, by = 0, c0 = 0, r0 = 0;
                get_afframe_sensor_res(&W, &H);
                if (W > 0) get_afframe_pos(W, H, &bx, &by);
                int ok = punch5x_get_window(&c0, &r0);
                log_line("  5x window %s: c7 %x c11 %x = columns %d.., rows %d..; AF box %d,%d", ok ? "seen" : "unknown", win_c7, win_c11, c0, r0, bx, by);
            }
            last_zoom = z; last_rec = RECORDING ? 1 : 0;
            if (z == 1) slow_reported = 0;
        }
        if (get_ms_clock() - t_flush > 1000 && !gui_menu_shown()) { t_flush = get_ms_clock(); log_flush(); }
    }
}

/* ---- menu ------------------------------------------------------------------ */
static MENU_UPDATE_FUNC(main_update)
{
    if (!movie_1080()) MENU_SET_WARNING(MENU_WARN_NOT_WORKING, "Canon movie mode, 1920x1080, LiveView.");
    MENU_SET_HELP("%s", status);
}
static MENU_UPDATE_FUNC(frame_update)
{
    if (p5_frame && fr_res_w) MENU_SET_RINFO("%dx%d%s", fr_res_w, fr_res_h, fr_from_rec ? "" : " (menu)");
}
static MENU_UPDATE_FUNC(status_update)
{
    MENU_SET_VALUE("%s", status);
}

static struct menu_entry punch_menu[] =
{
    {
        .name       = "5x punch-in",
        .priv       = &p5_enabled,
        .max        = 1,
        .update     = main_update,
        .help       = "Magnify = Canon's real 5x and back, also while recording (with REC5X).",
        .help2      = "1080p only. 10x is skipped: 5x -> 1x.",
        .submenu_width = 710,
        .children   = (struct menu_entry[]) {
            {
                .name       = "5x frame rate",
                .priv       = &p5_fps_mode,
                .max        = 1,
                .choices    = CHOICES("movie fps (23.976/25)", "Canon's 30 fps"),
                .help       = "Canon's 5x runs at 29.97 fps; this sets it to the movie frame rate (24p / 25p).",
                .help2      = "30p movies: nothing to change.",
            },
            {
                .name       = "Punch-in frame",
                .priv       = &p5_frame,
                .max        = 2,
                .choices    = CHOICES("off", "faint", "bright"),
                .update     = frame_update,
                .help       = "In 1x: dotted rectangle where the 5x punch-in will record (moves with the AF box).",
                .help2      = "Size = REC5X's output size. Erase (trash) button = centre the box.",
            },
            {
                .name       = "Align AF box",
                .priv       = &p5_align,
                .max        = 1,
                .help       = "At punch-in the AF box goes to the middle of the recorded area (the frame),",
                .help2      = "so the 5x screen shows exactly what is recorded. Back at punch-out.",
            },
            {
                .name       = "Centre 5x readout",
                .priv       = &p5_centre,
                .max        = 1,
                .help       = "Canon's 5x reads columns 0-3472 for a centred box: too far left for 1832 wide.",
                .help2      = "On: the 5x readout is centred on where you aim (CROPCTR-style), box moved to match.",
            },
            {
                .name       = "Frame without REC5X",
                .priv       = &p5_frame_h,
                .max        = 2,
                .choices    = CHOICES("1832x766", "1832x1030", "1832x1222"),
                .help       = "Frame size when REC5X isn't loaded (otherwise REC5X's resolution is used).",
            },
            {
                .name       = "Status",
                .update     = status_update,
                .icon_type  = IT_ALWAYS_ON,
                .help       = "What the module sees now.",
            },
            MENU_EOL
        },
    },
};

/* ---- module ------------------------------------------------------------------ */
static unsigned int punch_init(void)
{
    if (!is_camera("70D", "1.1.2")) return 0;
    log_t0 = get_ms_clock();
    if (PUNCH5X_LOG)
    {
        FIO_RemoveFile("ML/PUNCH5X.OLD");
        FIO_RenameFile("ML/PUNCH5X.LOG", "ML/PUNCH5X.OLD");
    }
    log_line("PUNCH5X v1.8 loaded");
    quit = 0;
    menu_add("Movie", punch_menu, COUNT(punch_menu));
    task_create("punch5x", 0x1e, 0x1000, worker, 0);
    return 0;
}

static unsigned int punch_deinit(void)
{
    quit = 1;
    fr_erase();
    remove_hooks();
    menu_remove("Movie", punch_menu, COUNT(punch_menu));
    return 0;
}

MODULE_INFO_START()
    MODULE_INIT(punch_init)
    MODULE_DEINIT(punch_deinit)
MODULE_INFO_END()

MODULE_CBRS_START()
    MODULE_CBR(CBR_KEYPRESS, punch_keypress, 0)
    MODULE_CBR(CBR_VSYNC, vsync_cbr, 0)
MODULE_CBRS_END()

MODULE_CONFIGS_START()
    MODULE_CONFIG(p5_enabled)
    MODULE_CONFIG(p5_fps_mode)
    MODULE_CONFIG(p5_frame)
    MODULE_CONFIG(p5_frame_h)
    MODULE_CONFIG(p5_align)
    MODULE_CONFIG(p5_centre)
MODULE_CONFIGS_END()
