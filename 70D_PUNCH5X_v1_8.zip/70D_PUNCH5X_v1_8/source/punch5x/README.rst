5x punch-in (70D)
=================

Canon 70D 1.1.2, movie 1080p. The magnify key switches between Canon's 1x
and Canon's real 5x view, also while recording RAW. Canon's 5x runs at the
movie frame rate (23.976 / 25 instead of 30). Use with the REC5X recorder
(mlv_lite with "1x/5x while recording"), which keeps the clip going through
the switch.

:Author: Claude (Anthropic) for Petar Stipanovic
:License: GPL
:Summary: 70D: magnify = Canon 5x at the movie frame rate, while recording too
