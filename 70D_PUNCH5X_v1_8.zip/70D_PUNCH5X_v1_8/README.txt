70D 5x punch-in - PUNCH5X v1.8 + REC5X v1.5 (2026-10-22)

Only change from PUNCH5X v1.7 / REC5X v1.4: logging is off.
- PUNCH5X no longer writes ML/PUNCH5X.LOG or renames it to .OLD.
- REC5X no longer appends to ML/LOGS/MLV_ZOOM.LOG.
Everything else (punch-in, timing, centring, recorder) is unchanged; the
on-screen messages (e.g. "use a width up to 1832") still appear.
Old PUNCH5X.LOG / .OLD / MLV_ZOOM.LOG files on the card are left alone -
delete them by hand if you like.

Install: copy ML/MODULES/PUNCH5X.MO and REC5X.MO over the old ones.
Settings are kept (same module names and config keys).

Logging back on for a debug build: add -DPUNCH5X_LOG=1 / -DREC5X_LOG=1 to
CFLAGS (or change the #define ... 0 to 1 in the source) and rebuild.

Build: magiclantern_simplified @ 1a0600a, platform 70D.112,
arm-none-eabi-gcc 13.2.1 (xPack 13.2.1-1.1), -Werror, 0 warnings.
Toolchain check: the v1.7 source rebuilt here gives a .text section identical
to the shipped v1.7 PUNCH5X.MO.
Imports: PUNCH5X 42 -> 36 (removed FIO_CloseFile, FIO_CreateFile,
FIO_RemoveFile, FIO_RenameFile, FIO_WriteFile, memcpy), REC5X 179 -> 178
(removed FIO_CreateFileOrAppend). Nothing added.

SHA-256
PUNCH5X.MO  3109623168ead90524fd5a49ee9c702507012caca53a791114c1ded0fca64d92
REC5X.MO    537fc0bf7622370dca5564a1296dfa0925b861a749090895523eef0aefbad73a

Source diffs: source/v1_7_to_v1_8_punch5x.diff, source/v1_4_to_v1_5_rec5x.diff
Not yet tested on the camera.
